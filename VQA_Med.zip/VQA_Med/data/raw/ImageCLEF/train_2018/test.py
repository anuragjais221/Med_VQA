import csv
file1 = open('/home/anurag/MVQAG/data/raw/ImageCLEF/train_2018/All_QA_Pairs_train.txt', 'a')
with open('/home/anurag/MVQAG/data/raw/ImageCLEF/train_2018/Train-QA.csv', newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter='\t', quotechar='|')
    for row in spamreader:
        row.pop(0)
        r = '|'.join(row)
        r =r+"\n"
        file1.write(r)
    # file1.close()